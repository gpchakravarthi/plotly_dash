import base64
import datetime
import io
import dash_auth
import dash
from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html
import dash_table
import plotly.graph_objects as go 
import pandas as pd

VALID_USERNAME_PASSWORD_PAIRS = {
    'a': 'a'
}

#'https://codepen.io/chriddyp/pen/bWLwgP.css',
external_stylesheets = ['https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css']
external_scripts= ['https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js'
                   ,'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js']
#,external_scripts=external_scripts
#https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js
#,'https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css'
app = dash.Dash(__name__, external_stylesheets=external_stylesheets,external_scripts=external_scripts)

auth = dash_auth.BasicAuth(
    app,
    VALID_USERNAME_PASSWORD_PAIRS
)

app.layout = html.Div([
    dcc.Upload(
        id='upload-data',
        children=html.Div([
            'Drag and Drop or ',
            html.A('Select File')
        ]),
        style={
            'width': '100%',
            'height': '60px',
            'lineHeight': '60px',
            'borderWidth': '1px',
            'borderStyle': 'dashed',
            'borderRadius': '5px',
            'textAlign': 'center',
            'margin': '10px'
        },
        # Allow multiple files to be uploaded
        multiple=True
    ),
    html.Div(id='output-data-features'),
    html.Div(id='output-data-upload'),#upload
    
])

def getk(col,dff):
    hh = list(dict(dff.groupby(col)[col].count()).keys())
    return [ '(' + str(x) + ')' for x in hh]

def getv(col,dff):
    hh = list(dict(dff.groupby(col)[col].count()).values())
    
    return [ x  for x in hh]

def getmx(col,dff):
    hh = list(dict(dff.groupby(col)[col].count()).values())
    return max(hh) + 1

def parse_contents(contents, filename, date):
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    global df
    try:
        if 'csv' in filename:
            # Assume that the user uploaded a CSV file
            
            df = pd.read_csv(
                io.StringIO(decoded.decode('utf-8')))
        elif 'xls' in filename:
            # Assume that the user uploaded an excel file
            
            df = pd.read_excel(io.BytesIO(decoded))
    except Exception as e:
        print(e)
        return html.Div([
            'There was an error processing this file.'
        ])

    return html.Div([
        html.Button('Get Configuration', id='get_config',className='btn btn-default'),
        html.H5(filename),
        html.H6(datetime.datetime.fromtimestamp(date)),
       
        html.Table(
        # Header
        
        [html.Tr([html.Th(
            #style={'display': 'none'},
            dcc.Graph(id = col +'his',
            figure = {'data':[{'x':getk(col,df),
                               'y':getv(col,df), 
                               'type':'bar','name':col},],
                      'layout':go.Layout(
                                height= 100,
                                width= 250,
                                xaxis={'title': ''},
                                yaxis={
                                    'title': '',
                                    'range':[0, getmx(col,df)]
                                },
                margin={'l': 40, 'b': 40, 't': 10, 'r': 0},)
                      })) for col in df.columns])],
        ),

        html.Table(
        # Header
        [html.Tr([html.Th(
            html.Div(id=col + '-dvv')
            ) for col in df.columns])],
        ),

        dash_table.DataTable(
            id='table-paging-and-sorting',
            style_cell={'fontSize':20, 'font-family':'sans-serif','minWidth': '250px', 'width': '250px', 'maxWidth': '250px'},
            style_data={'font-size':'15px'},
            data=df.to_dict('records'),
            columns=[{'name': i, 'id': i} for i in df.columns],
            page_current=0,
            page_size=20,
            page_action='custom',

            sort_action='custom',
            sort_mode='single',
            sort_by=[]  
        ),
        html.Hr()  # horizontal line

       
    ])#reading the data

@app.callback(Output('output-data-upload', 'children'),
              Input('upload-data', 'contents'),
              State('upload-data', 'filename'),
              State('upload-data', 'last_modified'))
              
def update_output(list_of_contents, list_of_names, list_of_dates):
    if list_of_contents is not None:
        children = [
            parse_contents(c, n, d) for c, n, d in
            zip(list_of_contents, list_of_names, list_of_dates)]
        return children # update data 

@app.callback(
    Output('table-paging-and-sorting', 'data'),
    Input('table-paging-and-sorting', "page_current"),
    Input('table-paging-and-sorting', "page_size"),
    Input('table-paging-and-sorting', 'sort_by'))

def update_table(page_current, page_size, sort_by):
    if len(sort_by):
            dff = df.sort_values(
                sort_by[0]['column_id'],
                ascending=sort_by[0]['direction'] == 'asc',
                inplace=False)
    else:
        # No sort is applied
        dff = df

    return dff.iloc[
        page_current*page_size:(page_current+ 1)*page_size
    ].to_dict('records')#sorting update

if __name__ == '__main__':
     app.run_server(port=5010)
