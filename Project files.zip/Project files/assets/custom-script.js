var vv = `           <div>
                     <select  font-size= "34px" id="cccc-drp" width="250px"   class="btn btn-primary dropdown-toggle selectpicker dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <option font-size= "34px" value="String">String</option>
                        <option font-size= "34px" value="Int">Int</option>
                        <option font-size= "34px" value="Date">Date</option>
                        <option font-size= "34px" value="Object">Object</option>
                      </select>
                      </div>
                      -----
                      <div>
                       <select  id="cccc-nx" class=" mdb-select multidd" width="250px" multiple data-live-search="true">
                            <option value="lower">lower</option>
                            <option value="trim">trim</option>
                            <option value="one-hot encoding">one-hot encoding</option>
                       </select>
                      </div>
                     -----
                      <div>
                       <select style="display:none;" id="cccc-ax" class="selectpicker multidd" width="250px" multiple data-live-search="true">
                            <option value="null_handling">null_handling</option>
                            <option value="outlier_handling">outlier_handling</option>
                       </select>
                       </div>
                       
                       <div>
                     -----
                     <select style="display:none;"  font-size= "34px" id="cccc-bx" width="250px"  class="btn btn-primary dropdown-toggle selectpicker dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <option font-size= "34px" value="-1">-1</option>
                        <option font-size= "34px" value="mean">mean</option>
                        
                      </select>
                      </div>
                     -----
                      <div>
                     <select style="display:none;"  font-size= "34px" id="cccc-cx" width="250px"  class="btn btn-primary dropdown-toggle selectpicker dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <option font-size= "34px" value="z-score">z-score</option>
                        <option font-size= "34px" value="IQR-score">IQR-score</option>
                        
                      </select>
                      </div>
                       
                      
                `

var tt = []
var con = {}
var ct = 0

$(document).ready(function () {
    
    if ($('#output-data-features').children().length === 0) {
        $('#output-data-features').append('<button id="get_config" class="btn btn-default "  style="display:none;" type="button">Get Configuration</button>')
    }
    
    function download(content, fileName, contentType) {
        var a = document.createElement("a");
        var file = new Blob([content], { type: contentType });
        a.href = URL.createObjectURL(file);
        a.download = fileName;
        a.click();
    }

    $('body').on('click', '#get_config', function (event) {
        download(JSON.stringify(con), 'config.json', 'text/plain')
    });


    $("body").mousemove(function (event) {
        $('table,table *').css('padding', '0px')
       

       
        if ($('#output-data-features').children().length === 0) {
            //$('#output-data-features').append('<button id="get_config" class="btn btn-default "  style="display:none;" type="button">Get Configuration</button>')
            //$('#output-data-features').append('<a id="exportJSON" onclick="exportJson(this);" class="btn"><i class="icon-download"></i> export json</a>')
        }
        for (i = 0; i < 5; i++) {
            $("[id$='-dvv"+ i +"']").each(function (index) {
                $('[type="file"]').parent().hide()
                //console.log(index + ": " + $(this).text());
                if ($(this).children().length === 0) {
                    idd = $(this).attr('id')
                    idd = idd.split('-')
                    tt.push(idd[0])
                    con[idd[0]] = {}
                    con[idd[0]]["selected_config"] = {}
                    con[idd[0]]["selected_config"]['Type'] = 'String'
                    con[idd[0]]["selected_config"]['sub_type'] = []
                    //con[idd[0]]["selected_config"]['sub_type']
                    ss = vv.replace(/cccc/g, idd[0])
                    sss = ss.split('-----')
                    $(this).append(sss[i])
                    
                    
                }
            });
        }
        
    })

    $('body').on('change', "[id$='-drp']", function (event) {

        $(':button').show()
        kkk = $(this).attr('id')
        sv = $('#' + kkk + ' option:selected').val()
        sp = kkk.split('-')[0]
        vll = sp + '-nx'
        ax = sp + '-ax'
        bx = sp + '-bx'
        cx = sp + '-cx'
        con[sp]["selected_config"]['Type'] = sv

        if (sv === 'String') {
            con[sp]["selected_config"]['sub_type'] = $("#" + vll).val()
            $("#" + vll).show()
            $("#" + ax).hide().val('')

        }
        else if (sv === 'Int') {
            con[sp]["selected_config"]['sub_type'] = $("#" + ax).val()
            $("#" + ax).show()
            $("#" + vll).hide().val('');

        } else {
            con[sp]["selected_config"]['sub_type'] = ''
            $("#" + vll).hide().val('');
            $("#" + ax).hide().val('');
        }
        if (sv !== 'Int') {
            $("#" + bx).hide().val('')
            $("#" + cx).hide().val('')
            if ('outlier_handling' in con[sp]["selected_config"]) {
                delete con[sp]["selected_config"]['outlier_handling']
            }
            if ('null_handling' in con[sp]["selected_config"]) {
                delete con[sp]["selected_config"]['null_handling']
            }

        }

    });

    $('body').on('change', "[id$='-nx'],[id$='-ax']", function (event) {

        kkk = $(this).attr('id')
        sp = kkk.split('-')[0]

        con[sp]["selected_config"]['sub_type'] = $(this).val()
    })

    $('body').on('change', "[id$='-ax']", function (event) {
        vl = $(this).val()
        kkk = $(this).attr('id')
        sp = kkk.split('-')[0]
        vll = sp + '-nx'
        ax = sp + '-ax'
        bx = sp + '-bx'
        cx = sp + '-cx'
        con[sp]["selected_config"]['null_handling'] = ''
        con[sp]["selected_config"]['outlier_handling'] = ''
        if (vl.includes('null_handling')) {
            con[sp]["selected_config"]['null_handling'] = $("#" + bx).val()
            $("#" + bx).show()
        }
        else {
            $("#" + bx).hide()
        }
        if (vl.includes('outlier_handling')) {
            $("#" + cx).show()
            con[sp]["selected_config"]['outlier_handling'] = $("#" + cx).val()
        }
        else {
            $("#" + cx).hide()
        }
    });
    $('body').on('change', "[id$='-bx']", function (event) {
        kkk = $(this).attr('id')
        sp = kkk.split('-')[0]
        con[sp]["selected_config"]['null_handling'] = $(this).val()
    })
    $('body').on('change', "[id$='-cx']", function (event) {
        kkk = $(this).attr('id')
        sp = kkk.split('-')[0]
        con[sp]["selected_config"]['outlier_handling'] = $(this).val()
    })

    const observer = new MutationObserver((mutations) => {
        console.log(mutations[0].target.text);
        
        if (mutations[0].target.text === 'Dash' ) {
            ct += 1
        }
        if (mutations[0].target.text === 'Updating...') {
            
        } else {
        }
        if (ct == 2) {
            
            setTimeout(function () {
                ('wheel').width('0px')
            }, 3000);
            observer.disconnect()
        }
    });

    observer.observe(document.querySelector("title"), {
        subtree: true,
        characterData: true,
        childList: true,
    })



})
